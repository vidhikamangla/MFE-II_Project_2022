df<-read.csv("C:/Users/Kartik/Downloads/Delhi.csv")
df

price<-df$Price
area<-df$Area

relation<-lm(price~area)

plot(area,price,col='blue')
abline(relation,cex = 1.3,pch = 16,xlab = "No Of Accidents",ylab = "Year")
summary(relation)

price<-df$Price
No_Of_bedrooms<-df$`No..of.Bedrooms`

relation<-lm(price~No_Of_bedrooms)

plot(No_Of_bedrooms,price,col='blue')
abline(relation,cex = 1.3,pch = 16,xlab = "No Of Accidents",ylab = "Year")
summary(relation)

data<-df

# Create a contingency table
contingency_table <- table(data$Price > mean(data$Price), data$SwimmingPool)

# Perform chi-squared test
chi_squared <- chisq.test(contingency_table)

# Output the results
cat("Chi-squared test results:\n")
cat("Test statistic:", chi_squared$statistic, "\n")
cat("p-value:", chi_squared$p.value, "\n")
cat("Degrees of freedom:", chi_squared$parameter, "\n")
cat("Conclusion:", ifelse(chi_squared$p.value < 0.05, "Reject the null hypothesis.", "Fail to reject the null hypothesis."), "\n")

contingency_table <- table(data$Price > 9800000, data$SportsFacility)
contingency_table
# Perform chi-squared test
chi_squared <- chisq.test(contingency_table)

# Output the results
cat("Chi-squared test results:\n")
cat("Test statistic:", chi_squared$statistic, "\n")
cat("p-value:", chi_squared$p.value, "\n")
cat("Degrees of freedom:", chi_squared$parameter, "\n")
cat("Conclusion:", ifelse(chi_squared$p.value < 0.05, "Reject the null hypothesis.", "Fail to reject the null hypothesis."), "\n")

