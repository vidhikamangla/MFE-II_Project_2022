library(knitr)
library(dbplyr)
library(dplyr)
library(tidyr)
library(combinat)
library(fAsianOptions)
library(fBasics)
library(fOptions)
library(ggplot2)
library(lubridate)
library(prob)
library(tidyverse)
library(timeDate)
library(timeSeries)
library(viridis)
library(viridisLite)
library(graphics)
library(grDevices)
uber_data <- read.csv("C:\\Users\\DELL\\Desktop\\UberDataset.csv")
head(uber_data)
summary(uber_data)

uber_data$START_DATE <- as.POSIXct(uber_data$START_DATE, format = "%m/%d/%Y %H:%M")
uber_data$END_DATE <- as.POSIXct(uber_data$END_DATE, format = "%m/%d/%Y %H:%M")


#it is cleaning the data by removing rows with missing values using dplyr package in r

data_clean <- drop_na(uber_data)


# Count the number of trips in each category
table(data_clean$CATEGORY)
# Group the data by purpose and calculate the mean distance and count for each group


data_clean %>%
  group_by(PURPOSE) %>%
  summarize(mean_distance = mean(MILES), count = n()) 


#1_Number of Trips by Category
ggplot(data_clean, aes(x = CATEGORY)) +
  geom_bar( width = 0.5) +
  labs(x = "Category", y = "Number of Trips", 
       title = "Number of Trips by Category")





#2 Number of Trips by Purpose
trips_by_purpose <- aggregate(START_DATE ~ PURPOSE, data = data_clean, FUN = length)
trips_by_purpose <- trips_by_purpose[order(trips_by_purpose$START_DATE, decreasing = TRUE),]
colors <- rainbow(11) # define colors for each category
ggplot(trips_by_purpose, aes(x = PURPOSE, y = START_DATE, fill = PURPOSE)) +
  geom_col() +
  scale_fill_manual(values = colors) + # set colors for each category
  labs(x = "Purpose", y = "Number of Trips", 
       title = "Number of Trips by Purpose") +
  coord_flip()




#3_Top 10 Start Locations for Uber Trips
top_start_locations <- data_clean %>% 
  count(START) %>% 
  arrange(desc(n)) %>% 
  slice(1:10)

# calculate the percentage of each start location and round to 1 decimal place
percentages <- round(100 * top_start_locations$n / sum(top_start_locations$n), 1)

# create the pie chart with labels and percentages
pie(top_start_locations$n, 
    labels = paste(top_start_locations$START, " (", percentages, "%)"),
    col = plasma(10),
    main = "Top 10 Start Locations for Uber Trips with percentage breakdown",
    cex = 1.0)



#4_distribution of rides based on time of the day
# Convert START_DATE to POSIXct format and create time_of_day variable
data_clean$START_DATE <- as.POSIXct(data_clean$START_DATE, format = "%m/%d/%Y %H:%M")
data_clean$time_of_day <- cut(as.numeric(format(data_clean$START_DATE, "%H")), 
                                   breaks = c(0, 5, 12, 17, 22, 24), 
                                   labels = c("Night", "Morning", "Afternoon", "Evening", "Night"))

# Compute the counts for each time of day
counts <- table(data_clean$time_of_day)

# Create the line chart
plot(counts, type = "l", col = "red", xlab = "Time of Day", ylab = "Number of Rides", 
     main = "Distribution of Rides by Time of Day")






#5_distribution of rides by months
# convert START_DATE column to datetime format
data_clean$START_DATE <- as.POSIXct(data_clean$START_DATE, format = "%m/%d/%Y %H:%M")

# create a new column for month
data_clean$month <- format(data_clean$START_DATE, "%m")

# count number of rides per month
rides_per_month <- data_clean %>%
  group_by(month) %>%
  summarise(total_rides = n())

# create line chart
ggplot(rides_per_month, aes(x = month, y = total_rides, group = 1)) +
  geom_line(color = "blue", size = 1) +
  geom_point(color = "blue", size = 2) +
  labs(x = "Month", y = "Number of Rides", 
       title = "Distribution of Rides by Month")




#6_distribution of rides based on day of week
data_clean$day_of_week <- weekdays(as.Date(data_clean$START_DATE))
ggplot(data_clean, aes(x = day_of_week)) +
  geom_bar(fill = viridis(7), width= 0.5) +
  labs(x = "Day of Week", y = "Number of Rides", 
       title = "Distribution of Rides by Day of Week")




#7_distribution of rides based on average Duration of Each Ride
data_clean$duration <- as.numeric(difftime(data_clean$END_DATE, data_clean$START_DATE, units = "mins"))
data_clean$month <- month(data_clean$START_DATE)
avg_duration_by_month <- aggregate(duration ~ month, data = data_clean, FUN = mean)
ggplot(avg_duration_by_month, aes(x = month, y = duration)) +
  geom_line(color = "#58508d", size = 1) +
  geom_point(color = "darkblue", size = 2) +
  scale_x_continuous(breaks = 1:12, labels = c("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")) +
  labs(x = "", y = "Average Duration (minutes)", 
       title = "Average duration of each ride")







