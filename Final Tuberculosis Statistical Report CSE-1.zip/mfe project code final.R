library(corrplot)

# Load the package
library(readxl)


# Set the encoding
options(readxl.include.colnames = FALSE, readxl.sheet = "Sheet1", readxl.skip = 1, encoding = "latin1")
# Read the Excel file
tb_data <- read.csv("C:/Users/Vidhika Mangla/OneDrive/Desktop/tubercolusis_from 2007_WHO_edited5.csv")

sapply(tb_data, class)
tb_data_clean <- na.omit(tb_data)

# view the cleaned dataset
tb_data_clean


# Calculate summary statistics for each variable
summary(tb_data)

#CORRELATION ANALYSIS:
# Select the columns of interest from your data
selected_cols <- c("NODEXHIV", "PREV",
                   "NODINHIV", "PREVPERPOP")

# Create a new data frame with only the selected columns
selected_data <- tb_data[selected_cols]

# Calculate the correlation matrix
cor_matrix <- cor(selected_data, use = "pairwise.complete.obs")

# Print the correlation matrix
print(cor_matrix)


install.packages("ggplot2")
library(ggplot2)

#CAN CALCULATE TOTAL NUMBER OF DEATHS FOR EACH CONTINENT YEARWISE, THEN MAKE A HISTOGRAM BAR PLOT FOR NODEXHIV AND NODINHIV FOR IT OVER TIME.

library(dplyr)

# Group by year and calculate the sum of NODEXHIV for each year
total_cases_yearwise_africa <- africa_data %>% 
  group_by(Year) %>% 
  summarize(total_cases = sum(NODINHIV))

total_cases_yearwise_africa

# Create the histogram

# Create the plot
ggplot(total_cases_yearwise_africa, aes(x = Year, y = total_cases, fill = factor(Year))) +
  geom_bar(stat = "identity") +
  scale_fill_manual(values = c("#C9B8E5", "#B2DBBF", "#F0C987", "#B0D1E8", "#FFB6C1", "#F8E2CF", "#AEC6CF", "#E2B8C4", "#C6DBEF")) +
  labs(x = "Year", y = "Total Cases", title = "Total TB Cases including HIV in Africa by Year (2007-2014)") +
  theme_minimal() +
  theme(plot.title = element_text(hjust = 0.5, size = 18, face = "bold"),
        axis.text = element_text(size = 14),
        axis.title = element_text(size = 16),
        legend.position = "none")


total_cases_yearwise_asia <- asia_data %>% 
  group_by(Year) %>% 
  summarize(total_cases = sum(NODINHIV))

total_cases_yearwise_asia

# Create the histogram
ggplot(total_cases_yearwise_asia, aes(x = Year, y = total_cases, fill = factor(Year))) +
  geom_bar(stat = "identity") +
  scale_fill_manual(values = c("#C9B8E5", "#B2DBBF", "#F0C987", "#B0D1E8", "#FFB6C1", "#F8E2CF", "#AEC6CF", "#E2B8C4", "#C6DBEF")) +
  labs(x = "Year", y = "Total Cases", title = "Total TB in Asia including HIV by Year (2007-2014)") +
  theme_minimal() +
  theme(plot.title = element_text(hjust = 0.5, size = 18, face = "bold"),
        axis.text = element_text(size = 14),
        axis.title = element_text(size = 16),
        legend.position = "none")

total_cases_yearwise_europe <- europe_data %>% 
  group_by(Year) %>% 
  summarize(total_cases = sum(NODINHIV))

total_cases_yearwise_europe

# Create the histogram
ggplot(total_cases_yearwise_europe, aes(x = Year, y = total_cases, fill = factor(Year))) +
  geom_bar(stat = "identity") +
  scale_fill_manual(values = c("#C9B8E5", "#B2DBBF", "#F0C987", "#B0D1E8", "#FFB6C1", "#F8E2CF", "#AEC6CF", "#E2B8C4", "#C6DBEF")) +
  labs(x = "Year", y = "Total Cases", title = "Total TB Cases in Europeincluding HIV by Year (2007-2014)") +
  theme_minimal() +
  theme(plot.title = element_text(hjust = 0.5, size = 18, face = "bold"),
        axis.text = element_text(size = 14),
        axis.title = element_text(size = 16),
        legend.position = "none")

total_cases_yearwise_northamerica <- northamerica_data %>% 
  group_by(Year) %>% 
  summarize(total_cases = sum(NODINHIV))

total_cases_yearwise_northamerica

# Create the histogram
ggplot(total_cases_yearwise_northamerica, aes(x = Year, y = total_cases, fill = factor(Year))) +
  geom_bar(stat = "identity") +
  scale_fill_manual(values = c("#C9B8E5", "#B2DBBF", "#F0C987", "#B0D1E8", "#FFB6C1", "#F8E2CF", "#AEC6CF", "#E2B8C4", "#C6DBEF")) +
  labs(x = "Year", y = "Total Cases", title = "Total TB Cases in North America inc HIV by Year (2007-2014)") +
  theme_minimal() +
  theme(plot.title = element_text(hjust = 0.5, size = 18, face = "bold"),
        axis.text = element_text(size = 14),
        axis.title = element_text(size = 16),
        legend.position = "none")


total_cases_yearwise_southamerica <- southamerica_data %>% 
  group_by(Year) %>% 
  summarize(total_cases = sum(NODINHIV))

total_cases_yearwise_southamerica

# Create the histogram
ggplot(total_cases_yearwise_southamerica, aes(x = Year, y = total_cases, fill = factor(Year))) +
  geom_bar(stat = "identity") +
  scale_fill_manual(values = c("#C9B8E5", "#B2DBBF", "#F0C987", "#B0D1E8", "#FFB6C1", "#F8E2CF", "#AEC6CF", "#E2B8C4", "#C6DBEF")) +
  labs(x = "Year", y = "Total Cases", title = "Total TB Cases in South America inc HIV by Year (2007-2014)") +
  theme_minimal() +
  theme(plot.title = element_text(hjust = 0.5, size = 18, face = "bold"),
        axis.text = element_text(size = 14),
        axis.title = element_text(size = 16),
        legend.position = "none")

total_cases_yearwise_oceania <- oceania_data %>% 
  group_by(Year) %>% 
  summarize(total_cases = sum(NODINHIV))

total_cases_yearwise_oceania

# Create the histogram
ggplot(total_cases_yearwise_oceania, aes(x = Year, y = total_cases, fill = factor(Year))) +
  geom_bar(stat = "identity") +
  scale_fill_manual(values = c("#C9B8E5", "#B2DBBF", "#F0C987", "#B0D1E8", "#FFB6C1", "#F8E2CF", "#AEC6CF", "#E2B8C4", "#C6DBEF")) +
  labs(x = "Year", y = "Total Cases", title = "Total TB Cases in Oceania inc HIV by Year (2007-2014)") +
  theme_minimal() +
  theme(plot.title = element_text(hjust = 0.5, size = 18, face = "bold"),
        axis.text = element_text(size = 14),
        axis.title = element_text(size = 16),
        legend.position = "none")



# Create histograms for each variable
histogram1=ggplot(tb_data_clean, aes(x=NODEXHIV)) +
  geom_histogram(color="black", fill="lightblue") +
  ggtitle("Distribution of Number of deaths due to tuberculosis, excluding HIV") +
  xlab("NODEXHIV") +
  ylab("Count")
# Extract the bin counts
bin_counts <- ggplot_build(histogram1)$data[[1]]$count
# Print the bin counts
print(bin_counts)
# Calculate the range 
range_values <- range(tb_data_clean$NODEXHIV, na.rm = TRUE)
# Calculate the bin width
bin_width <- diff(range_values) / 30 #30 is the number of bins
# Print the bin width
print(bin_width)
# Calculate the total count
total_count <- sum(bin_counts)
# Print the total count
print(total_count)

histogram2=ggplot(tb_data_clean, aes(x=PREV)) +
  geom_histogram(color="black", fill="lightblue") +
  ggtitle("Distribution of number of prevalent cases") +
  xlab("PREV") +
  ylab("Count")
bin_counts <- ggplot_build(histogram2)$data[[1]]$count
# Print the bin counts
print(bin_counts)
# Calculate the range 
range_values <- range(tb_data_clean$NODEXHIV, na.rm = TRUE)

histogram3=ggplot(tb_data_clean, aes(x=PREVSTART)) +
  geom_histogram(color="black", fill="lightblue") +
  ggtitle("Distribution of minimum number of prevalent cases") +
  xlab("PREVSTART") +
  ylab("Count")
bin_counts <- ggplot_build(histogram3)$data[[1]]$count
# Print the bin counts
print(bin_counts)
# Calculate the range 
range_values <- range(tb_data_clean$NODEXHIV, na.rm = TRUE)

histogram4=ggplot(tb_data_clean, aes(x=PREVEND)) +
  geom_histogram(color="black", fill="lightblue") +
  ggtitle("Distribution of maximum number of prevalent cases") +
  xlab("PREVEND") +
  ylab("Count")
bin_counts <- ggplot_build(histogram4)$data[[1]]$count
# Print the bin counts
print(bin_counts)
# Calculate the range 
range_values <- range(tb_data_clean$NODEXHIV, na.rm = TRUE)

histogram5=ggplot(tb_data_clean, aes(x=NODINHIV)) +
  geom_histogram(color="black", fill="lightblue") +
  ggtitle("Distribution of deaths due to tuberculosis among HIV-positive people (per 100000 population)") +
  xlab("NODINHIV") +
  ylab("Count")
bin_counts <- ggplot_build(histogram5)$data[[1]]$count
# Print the bin counts
print(bin_counts)
# Calculate the range 
range_values <- range(tb_data_clean$NODEXHIV, na.rm = TRUE)

histogram6=ggplot(tb_data_clean, aes(x=NODINHIVSTART)) +
  geom_histogram(color="black", fill="lightblue") +
  ggtitle("Distribution of minimum deaths due to tuberculosis among HIV-positive people (per 100000 population)") +
  xlab("NODINHIVSTART") +
  ylab("Count")
bin_counts <- ggplot_build(histogram6)$data[[1]]$count
# Print the bin counts
print(bin_counts)
# Calculate the range 
range_values <- range(tb_data_clean$NODEXHIV, na.rm = TRUE)

histogram7=ggplot(tb_data_clean, aes(x=NODINHIVEND)) +
  geom_histogram(color="black", fill="lightblue") +
  ggtitle("Distribution of maximum deaths due to tuberculosis among HIV-positive people (per 100000 population)") +
  xlab("NODINHIVEND") +
  ylab("Count")
bin_counts <- ggplot_build(histogram7)$data[[1]]$count
# Print the bin counts
print(bin_counts)
# Calculate the range 
range_values <- range(tb_data_clean$NODEXHIV, na.rm = TRUE)

histogram8=ggplot(tb_data_clean, aes(x=NODEXHIV)) +
  geom_histogram(color="black", fill="lightblue") +
  ggtitle("Distribution of maximum deaths due to tuberculosis among HIV-negative people (per 100000 population)") +
  xlab("NODEXHIV") +
  ylab("Count")
bin_counts <- ggplot_build(histogram8)$data[[1]]$count
# Print the bin counts
print(bin_counts)
# Calculate the range 
range_values <- range(tb_data_clean$NODEXHIV, na.rm = TRUE)

histogram9=ggplot(tb_data_clean, aes(x=NODEXHIVSTART)) +
  geom_histogram(color="black", fill="lightblue") +
  ggtitle("Distribution of minimum deaths due to tuberculosis among HIV-negative people (per 100000 population)") +
  xlab("NODEXHIVSTART") +
  ylab("Count")
bin_counts <- ggplot_build(histogram9)$data[[1]]$count
# Print the bin counts
print(bin_counts)
# Calculate the range 
range_values <- range(tb_data_clean$NODEXHIV, na.rm = TRUE)

histogram10=ggplot(tb_data_clean, aes(x=NODEXHIVEND)) +
  geom_histogram(color="black", fill="lightblue") +
  ggtitle("Distribution of maximum deaths due to tuberculosis among HIV-negative people (per 100000 population)") +
  xlab("NODEXHIVEND") +
  ylab("Count")
bin_counts <- ggplot_build(histogram10)$data[[1]]$count
# Print the bin counts
print(bin_counts)
# Calculate the range 
range_values <- range(tb_data_clean$NODEXHIV, na.rm = TRUE)

histogram11=ggplot(tb_data_clean, aes(x=PREVPERPOP)) +
  geom_histogram(color="black", fill="lightblue") +
  ggtitle("Distribution of prevalence of tuberculosis (per 100 000 population)") +
  xlab("PREVPERPOP") +
  ylab("Count")
bin_counts <- ggplot_build(histogram11)$data[[1]]$count
# Print the bin counts
print(bin_counts)
# Calculate the range 
range_values <- range(tb_data_clean$NODEXHIV, na.rm = TRUE)

histogram12=ggplot(tb_data_clean, aes(x=PREVPERPOPSTART)) +
  geom_histogram(color="black", fill="lightblue") +
  ggtitle("Distribution of minimum prevalence of tuberculosis (per 100 000 population)") +
  xlab("PREVPERPOPSTART") +
  ylab("Count")
bin_counts <- ggplot_build(histogram12)$data[[1]]$count
# Print the bin counts
print(bin_counts)
# Calculate the range 
range_values <- range(tb_data_clean$NODEXHIV, na.rm = TRUE)

histogram13=ggplot(tb_data_clean, aes(x=PREVPERPOPEND)) +
  geom_histogram(color="black", fill="lightblue") +
  ggtitle("Distribution of maximum prevalence of tuberculosis (per 100 000 population)") +
  xlab("PREVPERPOPEND") +
  ylab("Count")
bin_counts <- ggplot_build(histogram13)$data[[1]]$count
# Print the bin counts
print(bin_counts)
# Calculate the range 
range_values <- range(tb_data_clean$NODEXHIV, na.rm = TRUE)


library(ggplot2)
#
ggplot(tb_data, aes(x = Country, y = NODEXHIV)) +
  geom_boxplot(color = "lightpink") +
  labs(title = "Distribution of NODEXHIV by Country", x = "Country", y = "NODXHIV") +
  theme_dark()

ggplot(tb_data, aes(x = Country, y = NODINHIV)) +
  geom_boxplot(color = "lightpink") +
  labs(title = "Distribution of NODINHIV by Country", x = "Country", y = "NODXHIV") +
  theme_dark()

# Convert year column to date format
tb_data$Year <- as.Date(paste0(tb_data$Year, "-01-01"))


#Scatter plot to provide an overview of the trend of tuberculosis prevalence
#A STARTING POINT FOR FURTHER ANALYSIS
library(ggplot2)
ggplot(data = tb_data, aes(x = Year, y = PREV)) +
  geom_point(color = "purple", size = 3) +
  labs(x = "Year", y = "Prevalence", title = "Tuberculosis Prevalence from 2007 to 2014")

#Analysis of this scatter plot:
#The scatter plot also shows that some countries had much higher prevalence rates than others. 
#This may indicate that some countries need more resources and attention to control the spread of tuberculosis.

#3. The scatter plot also highlights that there was a significant drop in tuberculosis prevalence between 2013 
#and 2014. This could be due to improved screening, diagnosis, and treatment programs, increased awareness of 
#tuberculosis, and better living conditions.

#4. We can also see that the prevalence of tuberculosis is higher in some years than in others. 
#For instance, the prevalence was highest in 2007 and gradually declined until 2013, after which there was a
#sharp decline until 2014. This variation could be due to factors such as changes in healthcare policies,
#improvements in healthcare infrastructure, and better disease surveillance.



# Create line plot for prevalence over time for different continents for
#a deeper analysis of prevalence of tuberculosis cases.

ggplot(asia_data, aes(x = Year, y = PREV, color = Country, group = Country)) +
  geom_line() +
  labs(x = "Years", y = "Prevalence", color = "Country") +
  scale_color_discrete(name = "") +
  theme_bw() +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())

ggplot(europe_data, aes(x = Year, y = PREV, color = Country, group = Country)) +
  geom_line() +
  labs(x = "Years", y = "Prevalence", color = "Country") +
  scale_color_discrete(name = "") +
  theme_bw() +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())

ggplot(africa_data, aes(x = Year, y = PREV, color = Country, group = Country)) +
  geom_line() +
  labs(x = "Years", y = "Prevalence", color = "Country") +
  scale_color_discrete(name = "") +
  theme_bw() +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())

ggplot(northamerica_data, aes(x = Year, y = PREV, color = Country, group = Country)) +
  geom_line() +
  labs(x = "Years", y = "Prevalence", color = "Country") +
  scale_color_discrete(name = "") +
  theme_bw() +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())

ggplot(southamerica_data, aes(x = Year, y = PREV, color = Country, group = Country)) +
  geom_line() +
  labs(x = "Years", y = "Prevalence", color = "Country") +
  scale_color_discrete(name = "") +
  theme_bw() +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())

ggplot(oceania_data, aes(x = Year, y = PREV, color = Country, group = Country)) +
  geom_line() +
  labs(x = "Years", y = "Prevalence", color = "Country") +
  scale_color_discrete(name = "") +
  theme_bw() +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())

#Creating seperate dataframes for each continent after grouping countries continent wise
# create a vector of the countries to filter
countries <- c("Algeria", "Angola", "Benin", "Botswana", "Burkina Faso", "Burundi", "Cameroon", "Cabo Verde", "Central African Republic", "Chad", "Comoros", "Congo", "Cote d'Ivoire", "Democratic Republic of the Congo", "Djibouti", "Egypt", "Equatorial Guinea", "Eritrea", "Ethiopia", "Gabon", "Gambia", "Ghana", "Guinea", "Guinea-Bissau", "Kenya", "Lesotho", "Liberia", "Libya", "Madagascar", "Malawi", "Mali", "Mauritania", "Mauritius", "Morocco", "Mozambique", "Namibia", "Niger", "Nigeria", "Rwanda", "Sao Tome and Principe", "Senegal", "Seychelles", "Sierra Leone", "Somalia", "South Africa", "South Sudan", "Sudan", "Swaziland", "Tanzania", "Togo", "Tunisia", "Uganda", "Zambia", "Zimbabwe")

# subset the africa_data dataframe by the countries vector
africa_data <- subset(tb_data_clean, Country %in% countries)
head(africa_data)

# create a vector of the countries to filter
countries <- c("Afghanistan", "Bahrain", "Bangladesh", "Bhutan", "Brunei Darussalam", "Cambodia", "China", "Democratic People's Republic of Korea", "India", "Indonesia", "Iran (Islamic Republic of)", "Iraq", "Israel", "Japan", "Jordan", "Kazakhstan", "Kuwait", "Kyrgyzstan", "Lao People's Democratic Republic", "Lebanon", "Malaysia", "Maldives", "Mongolia", "Myanmar", "Nepal", "Oman", "Pakistan", "Philippines", "Qatar", "Republic of Korea", "Saudi Arabia", "Singapore", "Sri Lanka", "Syrian Arab Republic", "Tajikistan", "Thailand", "Timor-Leste", "Turkey", "Turkmenistan", "United Arab Emirates", "Uzbekistan", "Viet Nam", "Yemen")

# subset the tb_data dataframe by the countries vector
asia_data <- subset(tb_data_clean, Country %in% countries)
head(asia_data,20)

# create a vector of the countries to filter
countries <- c("Albania", "Andorra", "Armenia", "Austria", "Azerbaijan", "Belarus", "Belgium", "Bosnia and Herzegovina", "Bulgaria", "Croatia", "Cyprus", "Czech Republic", "Denmark", "Estonia", "Finland", "France", "Georgia", "Germany", "Greece", "Hungary", "Iceland", "Ireland", "Italy", "Kazakhstan", "Latvia", "Liechtenstein", "Lithuania", "Luxembourg", "Malta", "Monaco", "Montenegro", "Netherlands", "Norway", "Poland", "Portugal", "Republic of Moldova", "Romania", "Russian Federation", "San Marino", "Serbia", "Slovakia", "Slovenia", "Spain", "Sweden", "Switzerland", "The former Yugoslav republic of Macedonia", "Ukraine", "United Kingdom of Great Britain and Northern Ireland")

# subset the tb_data dataframe by the countries vector
europe_data <- subset(tb_data_clean, Country %in% countries)
head(europe_data)

# create a vector of the countries to filter
countries <- c("Canada", "Mexico", "United States of America")

# subset the tb_data dataframe by the countries vector
northamerica_data <- subset(tb_data_clean, Country %in% countries)
head(northamerica_data)

# create a vector of the countries to filter
countries <- c("Argentina", "Bolivia (Plurinational State of)", "Brazil", "Chile", "Colombia", "Costa Rica", "Cuba", "Dominica", "Dominican Republic", "Ecuador", "El Salvador", "Grenada", "Guatemala", "Guyana", "Haiti", "Honduras", "Jamaica", "Nicaragua", "Panama", "Paraguay", "Peru", "Saint Kitts and Nevis", "Saint Lucia", "Saint Vincent and the Grenadines", "Suriname", "Trinidad and Tobago", "Uruguay", "Venezuela (Bolivarian Republic of)")

# subset the tb_data dataframe by the countries vector
southamerica_data <- subset(tb_data_clean, Country %in% countries)
head(southamerica_data)

# create a vector of the countries to filter
countries <- c("Australia", "Cook Islands", "Fiji", "Kiribati", "Marshall Islands", "Micronesia (Federated States of)", "Nauru", "New Zealand", "Niue", "Palau", "Papua New Guinea", "Samoa", "Solomon Islands", "Tonga", "Tuvalu", "Vanuatu")

# subset the tb_data dataframe by the countries vector
oceania_data <- subset(tb_data_clean, Country %in% countries)
head(oceania_data)

# Find rows with non-numeric values in NODEXHIV
non_numeric_rows <- which(!is.na(tb_data$NODEXHIV) & !is.numeric(tb_data$NODEXHIV))

# Print the rows with non-numeric values in NODEXHIV
tb_data[non_numeric_rows, ]
sum(is.na(tb_data$NODEXHIV))

tb_data$NODEXHIV <- trimws(tb_data$NODEXHIV)
tb_data$NODEXHIV <- as.numeric(tb_data$NODEXHIV)

# Check the class of NODEXHIV
class(tb_data$NODEXHIV)



#trying linear regression


library(rsample)
library(dplyr)
library(tidyr)
library(caret)
install.packages("caret")
install.packages("rsample")

# Split data into training and testing sets for each continent
set.seed(42) # for reproducibility
Africa_split <- initial_split(africa_data, prop = 0.8)
Africa_train <- training(Africa_split)
Africa_test <- testing(Africa_split)

set.seed(42)
Asia_split <- initial_split(asia_data, prop = 0.8)
Asia_train <- training(Asia_split)
Asia_test <- testing(Asia_split)

set.seed(42)
Europe_split <- initial_split(europe_data, prop = 0.8)
Europe_train <- training(Europe_split)
Europe_test <- testing(Europe_split)

set.seed(42)
North_America_split <- initial_split(northamerica_data, prop = 0.8)
North_America_train <- training(North_America_split)
North_America_test <- testing(North_America_split)

set.seed(42)
Oceania_split <- initial_split(oceania_data, prop = 0.8)
Oceania_train <- training(Oceania_split)
Oceania_test <- testing(Oceania_split)

set.seed(42)
South_America_split <- initial_split(southamerica_data, prop = 0.8)
South_America_train <- training(South_America_split)
South_America_test <- testing(South_America_split)

# Train and test the model on each continent individually
Africa_model <- train(NODINHIV ~ PREV + PREVPERPOP, data = Africa_train, method = "glm", family = gaussian)
Africa_predictions <- predict(Africa_model, newdata = Africa_test)

Asia_model <- train(NODINHIV ~ PREV + PREVPERPOP, data = Asia_train, method = "glm", family = gaussian)
Asia_predictions <- predict(Asia_model, newdata = Asia_test)

Europe_model <- train(NODINHIV ~ PREV + PREVPERPOP, data = Europe_train, method = "glm", family = gaussian)
Europe_predictions <- predict(Europe_model, newdata = Europe_test)


North_America_model <- train(NODINHIV ~ PREV + PREVPERPOP, data = North_America_train, method = "glm", family = gaussian)
North_America_predictions <- predict(North_America_model, newdata = North_America_test)

Oceania_model <- train(NODINHIV ~ PREV + PREVPERPOP, data = Oceania_train, method = "glm", family = gaussian)
Oceania_predictions <- predict(Oceania_model, newdata = Oceania_test)

South_America_model <- train(NODINHIV ~ PREV + PREVPERPOP, data = South_America_train, method = "glm", family = gaussian)
South_America_predictions <- predict(South_America_model, newdata = South_America_test)

##TRYING TO FURTHER CLEAN AFRICA DATA

library(caret)
RMSE(Africa_predictions, Africa_test$NODINHIV)
RMSE(Asia_predictions, Asia_test$NODINHIV)
RMSE(Europe_predictions, Europe_test$NODINHIV)
RMSE(North_America_predictions, North_America_test$NODINHIV)
RMSE(South_America_predictions, South_America_test$NODINHIV)
RMSE(Oceania_predictions, Oceania_test$NODINHIV)



#APPLYING LINEAR REGRESSION ON THE WHOLE DATASET
# Split the data into training and testing sets
set.seed(123)
trainIndex <- createDataPartition(tb_data_clean$NODINHIV, p = .8, 
                                  list = FALSE, 
                                  times = 1)
train <- tb_data_clean[trainIndex,]
test <- tb_data_clean[-trainIndex,]
# Remove rows with "Niue" from test data
test <- test[test$Country != "Niue", ]

# Predict with updated test data
predictions <- predict(lm_model, newdata = test)

# Train the model using the training set
lm_model <- train(NODINHIV ~ ., data = train, method = "lm")

# Calculate the RMSE
RMSE(predictions, test$NODINHIV)

##cleaning africa data
# Identify numeric columns
num_cols <- sapply(africa_data, is.numeric)

# Apply scale function to numeric columns
scaled_data <- scale(africa_data[, num_cols])

# Calculate z-scores
z_scores <- apply(scaled_data, 2, abs)

# Identify and remove rows with z-scores > 3
africa_data <- africa_data[rowSums(z_scores < 3, na.rm = TRUE) == ncol(z_scores), ]

##cleaning asia data

num_cols <- sapply(asia_data, is.numeric)

# Apply scale function to numeric columns
scaled_data <- scale(asia_data[, num_cols])

# Calculate z-scores
z_scores <- apply(scaled_data, 2, abs)

# Identify and remove rows with z-scores > 3
asia_data <- asia_data[rowSums(z_scores < 3, na.rm = TRUE) == ncol(z_scores), ]


#From correlation matrix we can see that prevalence is statistically significant with no of deaths exclusing hiv
#and prevalence per population is statistically signigifcant with number of deaths including HIV

#Prevalence is the proportion of individuals in a population who have a specific disease or condition at
#a specific point in time, usually expressed as a percentage. 
#Prevalence per 100,000 population is a standardized rate that allows comparison of disease 
#prevalence between populations with different sizes. It is calculated by taking the total number of
#cases in a given population, dividing it by the total population, and then multiplying by 100,000. 
#The resulting number is the prevalence per 100,000 population. 
#The use of a standardized rate allows for comparison between populations of different sizes and 
#helps to account for differences in population size when making comparisons.


#using scatter plot to test the relationship:
library(ggplot2)

ggplot(tb_data, aes(x=PREV, y=NODEXHIV)) + 
  geom_point(color="blue", size=3) +
  labs(title="Relationship between Prevalence and Number of Deaths due to TB exluding hiv", x="Prevalent cases", y="Number of Deaths (excluding HIV)") +
  theme_minimal()
ggplot(tb_data, aes(x=PREV, y=NODINHIV)) + 
  geom_point(color="blue", size=3) +
  labs(title="Relationship between Prevalence  and Number of Deaths due to TB inluding hiv", x="Prevalent cases", y="Number of Deaths (including HIV)") +
  theme_minimal()

ggplot(tb_data, aes(x=PREVPERPOP, y=NODINHIV)) + 
  geom_point(color="blue", size=3) +
  labs(title="Relationship between Prevalence per population and Number of Deaths due to TB inluding hiv", x="Prevalent cases per population", y="Number of Deaths (including HIV)") +
  theme_minimal()
#There is an excellent positive linear relationship between the two variables as you can see from the plot
#An excellent linear relationship between Prevalence per population and Number of Deaths due to 
#TB including HIV means that there is a strong positive correlation between these two variables. 
#As the prevalence per population increases, the number of deaths due to TB including HIV also tends 
#to increase. The scatter plot shows a clear linear pattern, which indicates that a 
#linear regression model can be a good fit for these variables. This relationship could be used to 
#predict the number of deaths due to TB including HIV for a given prevalence per population value 
#or vice versa.


ggplot(tb_data, aes(x=PREVPERPOP, y=NODEXHIV)) + 
  geom_point(color="blue", size=3) +
  labs(title="Relationship between Prevalence per population and Number of Deaths due to TB exluding hiv", x="Prevalent cases per population", y="Number of Deaths (excluding HIV)") +
  theme_minimal()

# most of the points are on the x-axis, it may indicate that there is a weak or no 
#linear relationship between the two variables. 
#The few randomly scattered points suggest that there may be some outliers 

#Earlier we tried to apply a regression model with dependent variable as NODEINHIV and features as prevalence
#and prevalence per population.
#But now after looking at the scatter plots we will try to apply our linear model with just prevalence per pop as the predictor.

#APPLYING LINEAR MODEL AND TRYING TO PREDICT NODEXHIV WITH PREVALENCE AS A INDEPENDENT VARIABLE
# Train and test the model on each continent individually
Africa_model <- train(NODEXHIV ~ PREV, data = Africa_train, method = "glm", family = gaussian)
Africa_predictions <- predict(Africa_model, newdata = Africa_test)

Asia_model <- train(NODEXHIV ~ PREV, data = Asia_train, method = "glm", family = gaussian)
Asia_predictions <- predict(Asia_model, newdata = Asia_test)

Europe_model <- train(NODEXHIV ~ PREV, data = Europe_train, method = "glm", family = gaussian)
Europe_predictions <- predict(Europe_model, newdata = Europe_test)


North_America_model <- train(NODEXHIV ~ PREV, data = North_America_train, method = "glm", family = gaussian)
North_America_predictions <- predict(North_America_model, newdata = North_America_test)

Oceania_model <- train(NODEXHIV ~ PREV, data = Oceania_train, method = "glm", family = gaussian)
Oceania_predictions <- predict(Oceania_model, newdata = Oceania_test)

South_America_model <- train(NODEXHIV ~ PREV, data = South_America_train, method = "glm", family = gaussian)
South_America_predictions <- predict(South_America_model, newdata = South_America_test)

##TRYING TO FURTHER CLEAN AFRICA DATA

library(caret)
RMSE(Africa_predictions, Africa_test$NODINHIV)
RMSE(Asia_predictions, Asia_test$NODINHIV)
RMSE(Europe_predictions, Europe_test$NODINHIV)
RMSE(North_America_predictions, North_America_test$NODINHIV)
RMSE(South_America_predictions, South_America_test$NODINHIV)
RMSE(Oceania_predictions, Oceania_test$NODINHIV)

#We can see that the values are too high, so they are not a good fit at all, and we should not try to predict
#Number of deaths excluding HIV with prevalence as a factor.

#Similarly I also tried to train my model with NODINHIV and just one feature prevpop instead of both prev
#and pop like we did above, but the rmse values were too similar to eachother
#This suggests that prevpop feature alone has a strong enough relationship with NODINHIV and 
#adding the prevalence feature did not significantly improve the model's performance.

install.packages("rmarkdown")
